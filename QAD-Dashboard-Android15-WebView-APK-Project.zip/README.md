# QAD Dashboard — Android 15 (API 35) WebView APK

Targets **Android 15 (compileSdk = 35, targetSdk = 35, minSdk = 24)** with:
- Offline bundled HTML (`app/src/main/assets/index.html`)
- `enableEdgeToEdge()` + `WindowInsetsCompat` padding for Android 15 status & navigation bars
- Scoped Storage `MediaStore.Images` PNG export to `Pictures/QAD Dashboard` (zero storage permission dialogs on Android 15)
- Native Android Share Sheet via `FileProvider` for sending PNGs directly to WhatsApp

## Option A: Build APK in the Cloud (No PC / Android Studio Required)
1. Create a new GitHub repository and upload all files from this ZIP.
2. Open the **Actions** tab in your GitHub repository and run **Build Android 15 APK**.
3. Once finished (~2 minutes), download **QAD-Dashboard-Android15-APK** (`app-debug.apk`) directly onto your Android 15 phone and install it.

## Option B: Build Locally with Android Studio / CLI
1. Open this folder in **Android Studio Ladybug (2024.2.1+)** or newer.
2. Ensure **Android SDK Platform 35** is installed in SDK Manager.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `gradle assembleDebug`.
