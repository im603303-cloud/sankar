# Keep JavascriptInterface methods intact
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
